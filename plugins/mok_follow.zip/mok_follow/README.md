> **请注意：**
> 此项目已转移至 Github
> 这里将不再继续维护，请移步至 → [mokeyjay/mok_follow](https://github.com/mokeyjay/mok_follow)

#不关注 XX 贴吧不给绑定插件
基于`无名智者`的 [**贴吧云签到**](http://git.oschina.net/kenvix/Tieba-Cloud-Sign) 平台开发的插件

**管理员** 与 **VIP** 不受本插件限制